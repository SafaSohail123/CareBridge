# CareBridge — Full-stack MVP

A working healthcare-access website prototype with sign-up/sign-in and persistent server-side data storage.

## Included features
- Account creation, login and logout (password hashes; HTTP-only session cookie)
- User profile
- Symptom assessment with basic emergency warning-word checks and saved history
- Doctor directory with specialty, city and search filters
- Appointment request form and saved appointment requests
- Healthcare directory for hospitals and laboratories
- External pharmacy links (DVAGO, Dawaai and Sehat)
- Family profiles
- Medical-history text records
- Health reminders with completion status
- Responsive desktop/mobile interface

## Run locally
1. Install Node.js 18 or newer.
2. Extract this folder.
3. Open a terminal in this folder.
4. Run:
   ```bash
   npm install
   npm start
   ```
5. Open `http://localhost:5000`.

The SQLite database is created automatically at `data/carebridge.db`. It remains saved when the server restarts. Do not delete this file if you want to keep your data.

## Important configuration before deployment
Set a strong random `JWT_SECRET` environment variable. Use HTTPS, secure hosting, database backups, access controls, a privacy policy and a security review before using real patient information. This MVP is not a certified medical device or a substitute for clinical care.

## Prototype data and limitations
- Doctor and facility directory entries are sample/demo data and must be verified and replaced before public use. The listed contact details and fees are not guaranteed current.
- Appointment requests are stored in the database but are not sent to or confirmed by any clinic.
- Pharmacy buttons open third-party websites; no stock, order or price API is integrated.
- Symptom assessment is deliberately general and non-diagnostic. Its simple warning-word check is not clinically validated and cannot detect or rule out emergencies.
- Medical history stores text notes only; secure document upload is not included.
- Reminders are stored in the app. This version does not send push notifications, SMS or email.

## Suggested next production steps
1. Replace demo directories with verified providers and obtain permission to list them.
2. Integrate a real appointment provider/clinic workflow.
3. Have qualified clinicians design and validate symptom triage.
4. Add a secure file-upload service with encryption and malware scanning if records need attachments.
5. Add notification delivery and consent management.
6. Complete a privacy, security and legal review appropriate to Pakistan.
