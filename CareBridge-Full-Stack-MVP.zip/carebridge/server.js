const express = require("express");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_BEFORE_DEPLOYING_please_use_a_long_random_value";
const DATA_DIR = path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "carebridge.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, phone TEXT DEFAULT '', city TEXT DEFAULT 'Karachi',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS family_profiles (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 name TEXT NOT NULL, relationship TEXT NOT NULL, age INTEGER, notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS appointments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 doctor_id INTEGER, patient_name TEXT NOT NULL, appointment_date TEXT NOT NULL,
 appointment_time TEXT NOT NULL, reason TEXT DEFAULT '', status TEXT DEFAULT 'Requested',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS records (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL, record_type TEXT NOT NULL, record_date TEXT NOT NULL, notes TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reminders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL, reminder_date TEXT NOT NULL, reminder_time TEXT DEFAULT '', details TEXT DEFAULT '',
 completed INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS symptom_checks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 symptoms TEXT NOT NULL, duration TEXT NOT NULL, age INTEGER, severity TEXT NOT NULL,
 guidance TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const doctors = [
 {id:1,name:"Dr. Ayesha Khan",specialty:"General Physician",qualification:"MBBS, FCPS",experience:"8 years",fee:1500,city:"Karachi",clinic:"Care Medical Centre",languages:"Urdu, English",available:"Mon–Sat"},
 {id:2,name:"Dr. Hamza Ali",specialty:"Dermatologist",qualification:"MBBS, FCPS Dermatology",experience:"10 years",fee:2500,city:"Karachi",clinic:"City Skin Clinic",languages:"Urdu, English",available:"Mon–Fri"},
 {id:3,name:"Dr. Sara Ahmed",specialty:"Pediatrician",qualification:"MBBS, DCH",experience:"7 years",fee:1800,city:"Karachi",clinic:"Family Health Clinic",languages:"Urdu, English",available:"Mon–Sat"},
 {id:4,name:"Dr. Bilal Siddiqui",specialty:"Cardiologist",qualification:"MBBS, FCPS Cardiology",experience:"12 years",fee:3500,city:"Karachi",clinic:"Heart & Wellness Centre",languages:"Urdu, English",available:"Tue–Sat"},
 {id:5,name:"Dr. Mariam Noor",specialty:"Gynecologist",qualification:"MBBS, FCPS",experience:"9 years",fee:2500,city:"Karachi",clinic:"Women’s Care Clinic",languages:"Urdu, English",available:"Mon–Fri"},
 {id:6,name:"Dr. Usman Raza",specialty:"General Physician",qualification:"MBBS",experience:"5 years",fee:1200,city:"Lahore",clinic:"Community Medical Clinic",languages:"Urdu, English",available:"Mon–Sat"}
];
const facilities = [
 {id:1,name:"Jinnah Postgraduate Medical Centre",type:"Hospital",city:"Karachi",address:"Rafiqui Shaheed Road, Karachi",phone:"021-99201300",hours:"Confirm directly with facility",note:"Public-sector tertiary hospital; verify department availability before travelling."},
 {id:2,name:"Civil Hospital Karachi",type:"Hospital",city:"Karachi",address:"Baba-e-Urdu Road, Karachi",phone:"021-99215740",hours:"Confirm directly with facility",note:"Public-sector hospital; call ahead for non-emergency services."},
 {id:3,name:"Aga Khan University Hospital",type:"Hospital",city:"Karachi",address:"Stadium Road, Karachi",phone:"021-111-911-911",hours:"Confirm directly with facility",note:"Contact the hospital for current services and charges."},
 {id:4,name:"Indus Hospital & Health Network",type:"Hospital",city:"Karachi",address:"Korangi Crossing, Karachi",phone:"021-111-111-880",hours:"Confirm directly with facility",note:"Contact the facility to confirm clinic/service availability."},
 {id:5,name:"Chughtai Lab",type:"Laboratory",city:"Karachi",address:"Multiple collection centres; confirm nearest branch",phone:"03-111-456-789",hours:"Confirm directly with laboratory",note:"Confirm test availability, price and sample collection timing."},
 {id:6,name:"Essa Laboratory",type:"Laboratory",city:"Karachi",address:"Multiple collection centres; confirm nearest branch",phone:"021-111-_Essa (verify number)",hours:"Confirm directly with laboratory",note:"Confirm branch details and test availability before visiting."}
];
const pharmacies = [
 {id:1,name:"Dawaai",city:"Online / Pakistan",url:"https://dawaai.pk",note:"Check current stock, prescription requirements and delivery coverage."},
 {id:2,name:"DVAGO",city:"Karachi and other service areas",url:"https://dvago.pk",note:"Check current stock and delivery coverage for your area."},
 {id:3,name:"Sehat",city:"Online / Pakistan",url:"https://sehat.com.pk",note:"Check current product availability and prescription requirements."}
];

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

function auth(req,res,next) {
 const token = req.cookies.cb_token;
 if (!token) return res.status(401).json({error:"Please sign in to continue."});
 try { req.user = jwt.verify(token, JWT_SECRET); next(); }
 catch { res.clearCookie("cb_token"); return res.status(401).json({error:"Your session has expired. Please sign in again."}); }
}
function clean(v, max=500) { return String(v ?? "").trim().slice(0,max); }

app.post("/api/auth/signup", async (req,res) => {
 const name=clean(req.body.name,100), email=clean(req.body.email,160).toLowerCase(), password=String(req.body.password||"");
 if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8)
   return res.status(400).json({error:"Enter your name, a valid email and a password of at least 8 characters."});
 try {
   const hash=await bcrypt.hash(password,12);
   const result=db.prepare("INSERT INTO users(name,email,password_hash,phone,city) VALUES(?,?,?,?,?)")
     .run(name,email,hash,clean(req.body.phone,30),clean(req.body.city,80)||"Karachi");
   const user={id:Number(result.lastInsertRowid),name,email};
   const token=jwt.sign(user,JWT_SECRET,{expiresIn:"7d"});
   res.cookie("cb_token",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*24*60*60*1000});
   res.json({user});
 } catch(e) { res.status(409).json({error:"An account with this email may already exist."}); }
});
app.post("/api/auth/login", async (req,res) => {
 const email=clean(req.body.email,160).toLowerCase(), password=String(req.body.password||"");
 const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
 if (!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"Email or password is incorrect."});
 const safe={id:user.id,name:user.name,email:user.email};
 const token=jwt.sign(safe,JWT_SECRET,{expiresIn:"7d"});
 res.cookie("cb_token",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*24*60*60*1000});
 res.json({user:safe});
});
app.post("/api/auth/logout",(req,res)=>{res.clearCookie("cb_token");res.json({ok:true});});
app.get("/api/me",auth,(req,res)=>{
 const user=db.prepare("SELECT id,name,email,phone,city,created_at FROM users WHERE id=?").get(req.user.id);
 res.json({user});
});
app.put("/api/me",auth,(req,res)=>{
 db.prepare("UPDATE users SET name=?,phone=?,city=? WHERE id=?").run(clean(req.body.name,100),clean(req.body.phone,30),clean(req.body.city,80),req.user.id);
 res.json({user:db.prepare("SELECT id,name,email,phone,city FROM users WHERE id=?").get(req.user.id)});
});

app.get("/api/doctors",(req,res)=>{
 const q=clean(req.query.q,80).toLowerCase(), city=clean(req.query.city,80).toLowerCase(), spec=clean(req.query.specialty,80).toLowerCase();
 res.json(doctors.filter(d=>(!q||`${d.name} ${d.specialty} ${d.clinic}`.toLowerCase().includes(q))&&(!city||d.city.toLowerCase().includes(city))&&(!spec||d.specialty.toLowerCase()===spec)));
});
app.get("/api/facilities",(req,res)=>{
 const q=clean(req.query.q,80).toLowerCase(), type=clean(req.query.type,50).toLowerCase();
 res.json(facilities.filter(f=>(!q||`${f.name} ${f.city} ${f.address}`.toLowerCase().includes(q))&&(!type||f.type.toLowerCase()===type)));
});
app.get("/api/pharmacies",(req,res)=>res.json(pharmacies));

app.get("/api/appointments",auth,(req,res)=>res.json(db.prepare("SELECT * FROM appointments WHERE user_id=? ORDER BY appointment_date DESC, appointment_time DESC").all(req.user.id)));
app.post("/api/appointments",auth,(req,res)=>{
 const patient=clean(req.body.patient_name,100), date=clean(req.body.appointment_date,10), time=clean(req.body.appointment_time,10), reason=clean(req.body.reason,500), doctorId=Number(req.body.doctor_id)||null;
 if(!patient||!date||!time||!/^20\d\d-\d\d-\d\d$/.test(date)) return res.status(400).json({error:"Complete patient name, date and time."});
 const d=doctorId?doctors.find(x=>x.id===doctorId):null;
 const r=db.prepare("INSERT INTO appointments(user_id,doctor_id,patient_name,appointment_date,appointment_time,reason) VALUES(?,?,?,?,?,?)")
 .run(req.user.id,doctorId,patient,date,time,reason);
 res.json({id:Number(r.lastInsertRowid),status:"Requested",doctor:d?.name||"Doctor to be confirmed"});
});
app.delete("/api/appointments/:id",auth,(req,res)=>{
 const r=db.prepare("DELETE FROM appointments WHERE id=? AND user_id=?").run(Number(req.params.id),req.user.id);
 res.json({ok:r.changes>0});
});

app.get("/api/family",auth,(req,res)=>res.json(db.prepare("SELECT * FROM family_profiles WHERE user_id=? ORDER BY id DESC").all(req.user.id)));
app.post("/api/family",auth,(req,res)=>{
 const name=clean(req.body.name,100), rel=clean(req.body.relationship,60), age=Number(req.body.age)||null;
 if(!name||!rel) return res.status(400).json({error:"Enter a name and relationship."});
 const r=db.prepare("INSERT INTO family_profiles(user_id,name,relationship,age,notes) VALUES(?,?,?,?,?)").run(req.user.id,name,rel,age,clean(req.body.notes,500));
 res.json({id:Number(r.lastInsertRowid)});
});
app.delete("/api/family/:id",auth,(req,res)=>{const r=db.prepare("DELETE FROM family_profiles WHERE id=? AND user_id=?").run(Number(req.params.id),req.user.id);res.json({ok:r.changes>0});});

app.get("/api/records",auth,(req,res)=>res.json(db.prepare("SELECT * FROM records WHERE user_id=? ORDER BY record_date DESC").all(req.user.id)));
app.post("/api/records",auth,(req,res)=>{
 const title=clean(req.body.title,120), type=clean(req.body.record_type,60), date=clean(req.body.record_date,10);
 if(!title||!type||!date) return res.status(400).json({error:"Complete record title, type and date."});
 const r=db.prepare("INSERT INTO records(user_id,title,record_type,record_date,notes) VALUES(?,?,?,?,?)").run(req.user.id,title,type,date,clean(req.body.notes,1000));
 res.json({id:Number(r.lastInsertRowid)});
});
app.delete("/api/records/:id",auth,(req,res)=>{const r=db.prepare("DELETE FROM records WHERE id=? AND user_id=?").run(Number(req.params.id),req.user.id);res.json({ok:r.changes>0});});

app.get("/api/reminders",auth,(req,res)=>res.json(db.prepare("SELECT * FROM reminders WHERE user_id=? ORDER BY reminder_date,reminder_time").all(req.user.id)));
app.post("/api/reminders",auth,(req,res)=>{
 const title=clean(req.body.title,120), date=clean(req.body.reminder_date,10);
 if(!title||!date) return res.status(400).json({error:"Enter a reminder title and date."});
 const r=db.prepare("INSERT INTO reminders(user_id,title,reminder_date,reminder_time,details) VALUES(?,?,?,?,?)").run(req.user.id,title,date,clean(req.body.reminder_time,10),clean(req.body.details,500));
 res.json({id:Number(r.lastInsertRowid)});
});
app.patch("/api/reminders/:id",auth,(req,res)=>{
 const r=db.prepare("UPDATE reminders SET completed=? WHERE id=? AND user_id=?").run(req.body.completed?1:0,Number(req.params.id),req.user.id);
 res.json({ok:r.changes>0});
});
app.delete("/api/reminders/:id",auth,(req,res)=>{const r=db.prepare("DELETE FROM reminders WHERE id=? AND user_id=?").run(Number(req.params.id),req.user.id);res.json({ok:r.changes>0});});

app.post("/api/symptom-check",auth,(req,res)=>{
 const symptoms=clean(req.body.symptoms,600), duration=clean(req.body.duration,80), severity=clean(req.body.severity,30), age=Number(req.body.age)||null;
 if(!symptoms||!duration||!severity) return res.status(400).json({error:"Please complete all symptom assessment fields."});
 const redFlags=["chest pain","difficulty breathing","shortness of breath","unconscious","fainting","severe bleeding","stroke","face drooping","seizure","suicidal","severe allergic","blue lips"];
 const emergency=redFlags.some(w=>symptoms.toLowerCase().includes(w)) || severity==="Severe";
 const guidance=emergency
 ? "URGENT: Your answers include a warning sign. Seek emergency medical care now or contact local emergency services. Do not wait for an online assessment. This tool cannot diagnose or rule out an emergency."
 : "This tool cannot diagnose your condition. Monitor your symptoms and consider speaking with a licensed healthcare professional, especially if symptoms persist, worsen or concern you. A doctor can assess your history and decide whether tests or treatment are needed.";
 db.prepare("INSERT INTO symptom_checks(user_id,symptoms,duration,age,severity,guidance) VALUES(?,?,?,?,?,?)").run(req.user.id,symptoms,duration,age,severity,guidance);
 res.json({emergency,guidance,actions:["Book a doctor consultation","Find a healthcare facility"]});
});
app.get("/api/symptom-history",auth,(req,res)=>res.json(db.prepare("SELECT id,symptoms,duration,severity,guidance,created_at FROM symptom_checks WHERE user_id=? ORDER BY id DESC LIMIT 10").all(req.user.id)));

app.get("/api/dashboard",auth,(req,res)=>{
 const id=req.user.id;
 res.json({
 appointments:db.prepare("SELECT COUNT(*) n FROM appointments WHERE user_id=?").get(id).n,
 family:db.prepare("SELECT COUNT(*) n FROM family_profiles WHERE user_id=?").get(id).n,
 records:db.prepare("SELECT COUNT(*) n FROM records WHERE user_id=?").get(id).n,
 reminders:db.prepare("SELECT COUNT(*) n FROM reminders WHERE user_id=? AND completed=0").get(id).n
 });
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`CareBridge running at http://localhost:${PORT}`));
