# CareBridge – Netlify deploy

1. Push this folder to GitHub (or drag-drop it in Netlify; the function needs Git/CLI deploy to bundle, so prefer GitHub or `netlify deploy --prod`).
2. Netlify > Site settings > Environment variables: add `ANTHROPIC_API_KEY`.
3. Deploy. The AI pharmacist calls `/.netlify/functions/pharmacist`.

Edit doctors in `doctors.js` (Name|Specialty per hospital).
