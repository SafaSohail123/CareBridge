// Doctor directory. Format per line: Name | Specialty. Edit freely.
const RAW = {
"Aga Khan University Hospital": `Aamna Sanober|Plastic Surgery
Aamna Nazish Iqbal|Family Medicine
Aasma Naz|Speech and Occupational Therapy
Abdeali Khuzaima|Family Medicine
Abdul Monem|General Anaesthesia
Abdul Baqi|Cardiology
Abdul Ahad Chhotani|Emergency Medicine
Abdul Ghani Shaikh|Dentistry
Abdullah Bin Khalid|Gastroenterology
Abdul Rehman Qureshi|Nephrology
Abdul Rehman Siyal|General Paediatrics
Abdul Rehman Alvi|General Surgery`,
"Liaquat National Hospital": `Dr. Amanullah Khan|Spinal and Neurosurgery
Dr. Abdul Ahad|Paediatric Cardiology
Prof. Dr. Abdul Hameed Siddiqui|Ophthalmology
Dr. Abdul Rafay Qazi|Orthopaedic Surgery
Dr. Abeer Sarfaraz|Cardiology
Dr. Adeel Ahmed|Urology
Dr. Adnan Munir Khawaja|Urology
Dr. Afaq Saleem Siddiqui|Plastic and Reconstructive Surgery
Dr. Afifa Afsar|Spinal and Neurosurgery
Dr. Agha Ghulam Mustafa|Urology
Dr. Ahmad Nawaz|ENT
Dr. Ahmed Irfan|Spinal and Neurosurgery`,
"Lady Dufferin Hospital": `Dr. Shagufta Shaheen|Obstetrics/Gynae/Infertility
Dr. Naveera Agha|Obstetrics/Gynae/Infertility
Dr. Farkhanda Yasmeen|Obstetrics/Gynae/Infertility
Dr. Imrana Nayyer|Obstetrics/Gynae/Infertility
Dr. Rabia Arif|Obstetrics/Gynae/Infertility
Dr. Ramna Devi|Obstetrics/Gynae/Infertility
Dr. Mehwish Lakhani|Obstetrics/Gynae/Infertility
Dr. Rakshana Mahpara|Obstetrics/Gynae/Infertility
Dr. Husna Syed Ali|Obstetrics/Gynae/Infertility
Dr. Saba Aslam|Maternal Medicine
Dr. Faiza Sadaqat Ali|Gastroenterology
Dr. Ghulam Abbas|Cardiology
Dr. Humera Aziz|Gynae Oncology
Dr. Murtaza Ali|General Physician
Dr. Fatima Rafiq|General Physician
Dr. Ashraf Umer|Paediatrics
Dr. Gobind Ram|Paediatrics
Dr. Mehmood Shaikh|Paediatrics
Dr. Bashir Sheikh|General Surgery
Dr. Shafaq Naseer|General Surgery
Dr. Humaira Ghous|Haematology
Dr. Asma Maqsood|Diabetology
Dr. Shahab|Urology
Dr. M. Ali Yousaf|Urology
Dr. Sabiha Bano|Endocrinology
Ms. Nabila Suleman|Dietitian`,
"Burhani Hospital": `Dr. Amber Kamran|Cardiology
Dr. Sajida Imran|Gynaecology
Dr. Sobia Tabassum|Paediatrics
Dr. Asma Naveed|Nephrology
Dr. Tasneem Sadiq|Gynaecology
Dr. Shamim Haque|Gynaecology
Dr. Mumtu Bai|Gynaecology
Dr. Durdana Andaleeb|Gynaecology
Dr. Kulsoom Noor|Gynaecology
Dr. Musarrat Zahoor|Gynaecology
Dr. Rafia Qureshi|Gynaecology
Dr. Rehana Soomro|Gynaecology
Dr. Arifa Kausar Bhutto|Gynaecology
Dr. Rabia Saleem|Gynaecology
Dr. Haji Saleem|Paediatrics
Dr. Vedvi Yas Vaswani|Paediatrics
Dr. Rewa Chand|Paediatric Surgery
Dr. Syed Shahzad Ali|Paediatrics
Dr. Raj Kumar|Paediatrics
Dr. Hasnain Lokhandwala|Paediatrics
Prof. Dr. Abu Talib|General Physician
Dr. Syed Masroor Ahmed|General Physician
Dr. Pawan Kumar|General Physician
Dr. Gohar Ali|General Physician
Dr. Vijay Kumar|General Physician
Prof. Dr. Yousuf Lakhdawala|General Surgery
Dr. Bashir Sheikh|General Surgery
Prof. Dr. Imrana Aziz|General Surgery
Dr. Moti Ram|General Surgery
Dr. Nadia Haroon|General Surgery
Dr. Rabbia Zubair|General Surgery
Dr. Malik Wasim Ahmed|Orthopaedics
Dr. Manzoor Memon|Orthopaedics
Dr. Muzaffar Hussain|Orthopaedics
Prof. Dr. Jagdesh Kumar|Orthopaedics
Dr. Vinod Kumar|Orthopaedics
Dr. Ranjeet Kumar|Orthopaedics
Prof. Dr. Nisar Ahmed Siyal|Ophthalmology
Dr. Zeeshan Kamil|Ophthalmology
Dr. Vas Dev Harani|Ophthalmology
Prof. Dr. Ismail Hirani|ENT
Dr. Rajesh Kumar|ENT
Dr. Huzaifa Moiz|ENT
Dr. Ashok Kumar|Paediatrics
Dr. Sadiq Mian|ENT
Dr. Jai Parkash|Urology
Dr. Raja Rizwan|Urology
Dr. Niranjan Lal|Urology
Dr. Faizullah Lokhandwala|Pulmonology
Dr. Muhammad Zaheer|Pulmonology
Dr. Umair Dilawer|Pulmonology
Dr. Dileep Kumar|Neurology
Dr. Mohan Lal|Neurology
Dr. Farhad Ali|Neurosurgery
Dr. M. Sameer|Neurosurgery
Dr. A. Rab Nishtar|Dermatology
Dr. Rakhi Kumari|Dermatology
Dr. Huma Panja|Dermatology
Dr. Mehwish Miraj|Dermatology
Dr. Ghulam Abbas Shaikh|Cardiology
Dr. Mohsin Abbas Sheikh|Cardiology
Dr. Ajeet Kumar|Gastroenterology
Dr. Mukesh Kumar Panjwani|Gastroenterology
Dr. Shazia Shad|Gastroenterology
Dr. Capt. Liaquat Shaikh|Diabetology
Dr. Sajida Rashid|Endocrinology
Dr. Chooni Lal|Psychiatry
Dr. Anand Kumar|Psychiatry
Dr. M. Shan Ul Haq|Dentistry
Dr. Anum Haq|Dentistry
Dr. M. Tariq Fayyaz|Dentistry
Prof. Dr. Naveed Rasheed|Dentistry
Dr. Tauseef|Dentistry
Dr. Mukhtiar Ahmed|Radiology
Dr. Quresh Kothari|Sonology
Dr. Sadia Adnan|Sonology
Dr. Tasnim Sadiq|Sonology
Dr. Kailash|Radiology
Miss. Deeba Mumtaz|Physiotherapy
Dr. Atiqa Mehmood|Dietitian
Dr. Sandia Kumari|Sonology`,
"OMI Hospital": `Dr. Sana Azhar|Internal Medicine
Dr. Syed Ali Raza|Dentistry
Dr. Tasneem Fatima|Dentistry
Dr. Abdul Manan Junejo|Nephrology
Dr. Anita Haroon|Nephrology
Dr. Muhammad Irfan Hashmat|Neurology
Prof. Dr. S. Raza Khairat Rizvi|Neurosurgery
Dr. Shahnaz Shah|Neurology
Dr. Munir Afzal|Neurology
Prof. Dr. Atif Hafeez Siddiqui|ENT
Dr. Maisam A. Shiraz|ENT
Prof. Dr. Raheela Mohsin|Uro-Gynaecology
Dr. Farah Naz Raza|Gynaecology
Dr. Lubna Ali|Gynaecology
Dr. Paras Imran|Gynaecology
Dr. Saad Khalid Niaz|Gastroenterology
Dr. Muhammad Asim|Gastroenterology
Prof. Dr. Bader Faiyaz Zuberi|Gastroenterology
Prof. Dr. Zaigham Abbas|Gastroenterology
Dr. Raja Muhammad Shahzad Khan|Orthopaedics
Dr. Aslam Pervez|Surgery
Prof. Dr. Zaki Idrees|Surgery
Dr. Syed Uzair Ali|Surgery
Dr. Syed Ali Abbas|Pulmonology
Prof. Dr. Shabbir Hussain|Paediatric Surgery
Dr. Murtaza Ali Gowa|Paediatrics
Dr. Syed Shakil Ahmed Rizvi|Paediatrics
Prof. Dr. Nasir Saleem Saddal|Paediatric Surgery
Dr. Shazia Kulsoom|Paediatric Neurology
Dr. Muhammad Hanif|Paediatrics
Dr. Muhammad Ashraf Ganatra|Surgery
Dr. Tahir Sheikh|Surgery
Dr. Masood Ahmed Sheikh|Surgery
Dr. Shahzad Ali|Urology
Prof. Dr. Faisal Ahmed|Cardiology
Dr. Umair Abrar|Cardiology
Dr. Usman H. Bhatti|Cardiology
Dr. Ghulam Abbas Shaikh|Cardiology
Dr. Syed Asadullah Hussaini|Cardiology
Dr. Tariq Ishaq|Cardiology`,
"KGH": `Dr. Mushtaque Ali Badami|General Physician
Dr. Rajesh Motwani|General Physician
Dr. Muhammad Rehan|General Physician
Dr. Asif Nasim|Chest Physician
Dr. Fazal Hakim|Chest Physician
Dr. Dileep Kumar|Cardiology
Dr. Mustajab Mujtaba|Cardiology
Dr. Jai Perkash|Neurology
Dr. Yahya|Neurology
Dr. Kishor Kumar|Psychiatry
Dr. Sandeep Kumar|Nephrology
Dr. Farooq Memon|Diabetology`
};
const doctors = Object.entries(RAW).flatMap(([hospital, txt]) =>
  txt.split("\n").map(l => { const [name, specialty] = l.split("|"); return { name: name.trim(), hospital, specialty: specialty.trim() }; })
);
